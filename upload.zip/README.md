# Pass The Mic
A Chrome Extensions for visualizing how much each person is talking in Google Meet.

## Misc